#!/usr/bin/env ruby
require_relative '../config'
require 'net/ssh'
require 'net/scp'
require 'cgi'


module View
  def escape_html(text)
    CGI.escapeHTML(text).sub("\n", "<br>")
  end
end


module QueryServer
  def to_hosts(*hostname)
    hosts = {}.merge!( $hosts.select {|k,v| hostname.include?(k)} )
    return hosts
  end
  def ssh(script, *hostname)
    result = []
    hosts = self.to_hosts(*hostname)
    hosts.each_key do |e|
      ip = hosts[e]
      Net::SSH.start(
        ip,
        $user_ssh,
        :password => $password_ssh,
        :port => $port_ssh
      ) do |ssh| 
        #result << [ e, ip, script, ssh.exec!(script) ]
        result << ssh.exec!(script)
      end
    end
=begin
    if result.length == 1 and result[0].is_a?(Array)
      return result.flatten
    else
      return result
    end
=end
    return result
  end
  def upload_web(filename, content)
    path = "uploads/#{filename}"
    return File.open(path, 'w') { |f| f.write(content.read) }
=begin
    if File.exists?(path)
      return nil
    else
      return "upload failed: " + path
    end
=end
  end
  def upload_scp(path, *hostname)
    filename = File.basename(path)
    result = []
    result << self.ssh("[[ -f /temp/#{filename} ]] && sudo rm -rf /temp/#{filename}", *hostname)
    hosts = self.to_hosts(*hostname)

    result_scp = []
    hosts.each_key do |e|
      Net::SCP.start(
        hosts[e],
        $user_ssh,
        :password => $password_ssh, 
        :port => $port_ssh,
      ) do |scp| 
        result_scp << scp.upload!( "uploads/#{filename}", "/temp" )
      end
    end
    result << result_scp

    result << self.ssh("sudo cp /temp/#{filename} #{path}", *hostname)
    return result
  end
end

