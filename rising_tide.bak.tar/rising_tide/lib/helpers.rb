#!/usr/bin/env ruby
require_relative 'common'

module Helpers
  include View
  class RisingTide
    include QueryServer
    def redis_flush(*hostname)
      script = <<-header
        cd /u/db/redis-2.4.3 && \
        sudo -u redis ./client.sh <<EOF
        flushall
        quit
EOF
      header
      self.ssh(script, *hostname)
    end
    def subfile(path, content, *hostname)     #def subfile(options={})
      filename = File.basename(path)
      result = []
      result << self.upload_web(filename, content)
      result << self.upload_scp(path, *hostname)
      return result.flatten!(1)
    end
    def deploy(hostname, *package)
      package
    end
  end
end


