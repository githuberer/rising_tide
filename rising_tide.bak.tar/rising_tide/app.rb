#!/usr/bin/env ruby
require 'sinatra'
require 'sinatra/reloader' if development?
require_relative 'lib/helpers'


set :port, '4567'
set :bind, '127.0.0.1'
set :lock, true
set :sessions, true                         # disabled default
#set environment, :production
#set :show_exceptions, false
#set :root, File.dirname(__FILE__)          # set application’s root directory to current file's dir
#set :app_file, __FILE__


use Rack::Auth::Basic, "RisingTide-Manager" do |username, password|
  username == 'admin' and password == 'admin'
end


helpers do 
  include Helpers
end
rtide = Helpers::RisingTide.new


#####Routes#####################

get '/test' do
  params.inspect
end

get '/' do
  erb :index
end

get '/redis' do
  redirect '/redis/flush'
end
get '/redis/flush' do
  erb :redis_flush_get
end
post '/redis/flush' do
  #params.inspect
  hostname = params['hostname']
  params['result'] = rtide.redis_flush(*hostname)
  erb :redis_flush_post
end

get '/subfile' do
  erb :subfile_get
end
post '/subfile' do
  hostname = params['hostname']
  params['result'] = []

  result = rtide.subfile(
    params['path'].strip,                   # path(remote server)
    params['myfile'][:tempfile],            # content
    *hostname                               # hostname
  )

  params['result'] << "upload_web error:" + result[0] if not result[0] == "8"
  if result[1][0] == nil
    

  params.inspect
  #params['result'].inspect
  #erb :subfile_post
end

get '/deploy' do
  erb :deploy_get
end
post '/deploy' do
  package = params['package']
  params['result'] = rtide.deploy("v5backup", *package)
  #erb :deploy_post
  params.inspect
end


